# Cycle four sitting

Talk only. Start at `daydream-packet.md`.

Read with the other files in this zip. Findings come back to
`loom-weave-godot` `artifacts/findings/`.
